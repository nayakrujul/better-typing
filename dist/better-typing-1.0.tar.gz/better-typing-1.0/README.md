# better-typing
A better version of typing in Python.
